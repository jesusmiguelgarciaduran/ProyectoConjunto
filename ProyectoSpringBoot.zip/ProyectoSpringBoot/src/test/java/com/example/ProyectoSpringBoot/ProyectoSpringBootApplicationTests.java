package com.example.ProyectoSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
