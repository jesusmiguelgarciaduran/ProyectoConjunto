package com.bootcamp.LibreriaApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibreriaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
