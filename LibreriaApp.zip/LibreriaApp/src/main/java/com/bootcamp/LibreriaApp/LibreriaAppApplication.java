package com.bootcamp.LibreriaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibreriaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibreriaAppApplication.class, args);
	}

}
