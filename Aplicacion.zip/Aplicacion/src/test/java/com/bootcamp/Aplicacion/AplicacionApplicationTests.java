package com.bootcamp.Aplicacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
