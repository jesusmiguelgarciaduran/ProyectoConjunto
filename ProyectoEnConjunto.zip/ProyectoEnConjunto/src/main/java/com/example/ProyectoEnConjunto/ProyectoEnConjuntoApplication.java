package com.example.ProyectoEnConjunto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoEnConjuntoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoEnConjuntoApplication.class, args);
	}

}
